const validateConvoAccess = require('./convoAccess');
module.exports = {
  validateConvoAccess,
};
