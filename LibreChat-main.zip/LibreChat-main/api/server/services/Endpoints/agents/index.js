const build = require('./build');
const initialize = require('./initialize');

module.exports = {
  ...build,
  ...initialize,
};
