const initializeCustomAgent = require('./CustomAgent/initializeCustomAgent');
const initializeFunctionsAgent = require('./Functions/initializeFunctionsAgent');

module.exports = {
  initializeCustomAgent,
  initializeFunctionsAgent,
};
